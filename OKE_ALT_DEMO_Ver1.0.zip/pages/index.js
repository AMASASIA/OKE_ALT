
import { useEffect, useState } from "react";
import { ethers } from "ethers";
import WalletUI from "../components/WalletUI";
import contractABI from "../contracts/SampleContract.json";

export default function Home() {
  const [email, setEmail] = useState("");
  const [walletAddress, setWalletAddress] = useState("");
  const [status, setStatus] = useState("");
  const [contract, setContract] = useState(null);

  const contractAddress = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS;

  useEffect(() => {
    if (typeof window.ethereum !== "undefined") {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      const signer = provider.getSigner();
      const c = new ethers.Contract(contractAddress, contractABI.abi, signer);
      setContract(c);
    }
  }, []);

  const connectWallet = async () => {
    window.open("https://idqsoulwallet.vercel.app/", "_blank");
  };

  const mintNFT = async () => {
    if (!contract) return;
    try {
      const tx = await contract.mint(walletAddress);
      await tx.wait();
      setStatus("✅ Mint successful");
    } catch (err) {
      console.error(err);
      setStatus("❌ Mint failed");
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 text-black p-8">
      <h1 className="text-3xl font-bold mb-4">OKE_ALT NFT/SBT Issuer</h1>

      <div className="mb-4">
        <label className="block text-sm font-medium mb-1">Email Address:</label>
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full p-2 border rounded"
          placeholder="you@example.com"
        />
      </div>

      <div className="mb-4">
        <button onClick={connectWallet} className="bg-black text-white px-4 py-2 rounded">
          Connect Wallet
        </button>
      </div>

      <div className="mb-4">
  <button onClick={mintNFT} className="bg-indigo-600 text-white px-4 py-2 rounded mt-2">
    Mint NFT + SBT
  </button>
</div>

      {status && <p className="mt-4">{status}</p>}
    </div>
  );
}
