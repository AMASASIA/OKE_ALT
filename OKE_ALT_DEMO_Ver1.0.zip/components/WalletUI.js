// Sample Wallet UI component
